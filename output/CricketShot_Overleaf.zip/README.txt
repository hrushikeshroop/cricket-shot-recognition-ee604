Compile main.tex for the revised CVPR manuscript and supplementary evidence. The unmodified 2022 style is included.
The current complete report and entire source appendix are included. After editing, export main.pdf and run:
python -m pip install pymupdf
python merge_report.py main.pdf code_appendix.pdf complete_updated.pdf
The PDF merge avoids the 2022 style's embedded eso-pic conflict with pdfpages.
